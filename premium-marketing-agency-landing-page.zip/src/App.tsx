import { useEffect, useState, useRef } from 'react'

const WHATSAPP_LINKS = {
  hero: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Quero%20atrair%20mais%20clientes%20para%20minha%20empresa.",
  trafego: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Tenho%20interesse%20em%20saber%20mais%20sobre%20Tr%C3%A1fego%20Pago%20para%20minha%20empresa.",
  sites: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Tenho%20interesse%20em%20um%20Site%20Profissional%20para%20minha%20empresa.",
  ia: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Tenho%20interesse%20em%20conhecer%20o%20Agente%20de%20IA%20para%20WhatsApp.",
  demonstracao: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Quero%20testar%20o%20agente%20de%20IA.",
  especialista: "https://wa.me/5511953851744?text=Ol%C3%A1%21%20Quero%20falar%20com%20um%20especialista%20sobre%20estrat%C3%A9gia%20digital%20para%20minha%20empresa.",
}

function trackEvent(eventName: string, payload?: any) {
  console.log(`[Analytics Event] ${eventName}`, payload)
  // @ts-ignore
  if (typeof window !== 'undefined' && window.gtag) window.gtag('event', eventName, payload)
  // @ts-ignore
  if (typeof window !== 'undefined' && window.fbq) window.fbq('trackCustom', eventName, payload)
}

export default function App() {
  const [mobileMenu, setMobileMenu] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const [agenciaNome] = useState("NicoTech")
  const servicosRef = useRef<HTMLDivElement>(null)
  const problemasRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' })
      setMobileMenu(false)
    }
  }

  const showToast = (msg: string) => {
    setToast(msg)
    setTimeout(() => setToast(null), 3000)
  }

  const handleWpp = (type: keyof typeof WHATSAPP_LINKS, label: string) => {
    trackEvent('whatsapp_click', { button: label, type })
    // toast for UX feedback before opening
  }

  return (
    <div className="min-h-screen bg-[#050E1F] text-white overflow-x-hidden selection:bg-[#00D084]/30 selection:text-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap');
        h1,h2,h3,h4 { font-family: 'Sora', sans-serif; }
        * { scroll-behavior: smooth; }
        .glass { background: rgba(255,255,255,0.06); backdrop-filter: blur(16px); border: 1px solid rgba(255,255,255,0.08); }
        .glass-strong { background: rgba(255,255,255,0.08); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.12); }
        .text-gradient { background: linear-gradient(90deg, #00D084 0%, #00B6FF 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .btn-glow { box-shadow: 0 0 30px rgba(0,208,132,0.4), 0 8px 24px rgba(0,0,0,0.3); }
        .btn-glow:hover { box-shadow: 0 0 40px rgba(0,208,132,0.55), 0 10px 30px rgba(0,0,0,0.4); transform: translateY(-1px); }
        .animate-float { animation: float 6s ease-in-out infinite; }
        .animate-float-delay { animation: float 6s ease-in-out infinite 2s; }
        @keyframes float { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-10px) } }
        @keyframes pulse-glow { 0%,100% { opacity: 0.6 } 50% { opacity: 1 } }
      `}</style>

      {/* Topbar */}
      <div className="hidden md:flex bg-[#00D084] text-[#031022] text-[12px] font-semibold tracking-wide justify-center items-center py-2 px-4 gap-6">
        <span className="flex items-center gap-2">● Atendimento em Guarulhos e região</span>
        <span className="hidden lg:flex items-center gap-2">✦ Resposta em até 15 minutos no WhatsApp</span>
        <a href={WHATSAPP_LINKS.hero} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('hero', 'topbar_whatsapp')} className="underline decoration-2 underline-offset-4 hover:opacity-80">Falar no WhatsApp →</a>
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[#050E1F]/80 backdrop-blur-xl border-b border-white/10' : 'bg-transparent border-b border-white/5'}`}>
        <div className="max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8 flex items-center justify-between h-[72px]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00D084] to-[#00B6FF] flex items-center justify-center font-extrabold text-[#031022] text-lg">◈</div>
            <div>
              <div className="font-extrabold tracking-tight text-[18px] leading-none" style={{ fontFamily: 'Sora, sans-serif' }}>{agenciaNome}</div>
              <div className="text-[10px] tracking-[0.18em] text-white/60 font-semibold">GUARULHOS • SP</div>
            </div>
            <span className="hidden md:inline-flex ml-2 px-2.5 py-1 rounded-full bg-white/10 border border-white/10 text-[10px] font-bold tracking-widest text-white/80">PREMIUM</span>
          </div>

          <nav className="hidden lg:flex items-center gap-8 text-[13px] font-medium text-white/80">
            <button onClick={() => scrollTo('problema')} className="hover:text-white transition">Como ajudamos</button>
            <button onClick={() => scrollTo('servicos')} className="hover:text-white transition">Soluções</button>
            <button onClick={() => scrollTo('como-funciona')} className="hover:text-white transition">Processo</button>
            <button onClick={() => scrollTo('demonstracao')} className="hover:text-white transition">Demonstração IA</button>
          </nav>

          <div className="flex items-center gap-3">
            <a href={WHATSAPP_LINKS.hero} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('hero', 'header_cta')}
              className="hidden md:inline-flex items-center gap-2 bg-[#00D084] hover:bg-[#00c27a] text-[#031022] font-extrabold text-[13px] px-5 py-3 rounded-full transition btn-glow">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" /> FALAR NO WHATSAPP
            </a>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="lg:hidden w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center">
              <span className="text-lg">{mobileMenu ? '✕' : '☰'}</span>
            </button>
          </div>
        </div>
        {mobileMenu && (
          <div className="lg:hidden border-t border-white/10 bg-[#081428] px-4 py-6 space-y-4">
            <button onClick={() => scrollTo('problema')} className="block w-full text-left py-2 text-white/90">Como ajudamos</button>
            <button onClick={() => scrollTo('servicos')} className="block w-full text-left py-2 text-white/90">Soluções</button>
            <button onClick={() => scrollTo('como-funciona')} className="block w-full text-left py-2 text-white/90">Processo</button>
            <button onClick={() => scrollTo('demonstracao')} className="block w-full text-left py-2 text-white/90">Demonstração IA</button>
            <a href={WHATSAPP_LINKS.hero} target="_blank" onClick={() => handleWpp('hero', 'mobile_cta')} className="flex justify-center items-center gap-2 bg-[#00D084] text-[#031022] font-extrabold py-3 rounded-full">FALAR NO WHATSAPP</a>
          </div>
        )}
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        {/* Background gradients */}
        <div className="absolute inset-0 bg-[#050E1F]" />
        <div className="absolute -top-[300px] -right-[300px] w-[800px] h-[800px] bg-[#00B6FF]/20 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute -top-[100px] -left-[200px] w-[600px] h-[600px] bg-[#00D084]/15 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[1000px] h-[400px] bg-gradient-to-t from-[#04122B]/60 to-transparent blur-2xl" />

        <div className="relative max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8 pt-10 md:pt-14 pb-12 md:pb-20 grid lg:grid-cols-[1.05fr_1fr] gap-10 lg:gap-8 items-center">
          {/* Left */}
          <div className="relative">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-[11px] font-semibold tracking-wide text-white/80 mb-6">
              <span className="w-2 h-2 bg-[#00D084] rounded-full animate-pulse" /> ATENDIMENTO EM GUARULHOS E REGIÃO • VAGAS LIMITADAS ESTE MÊS
            </div>

            <h1 className="text-[36px] md:text-[52px] lg:text-[56px] font-extrabold leading-[0.95] tracking-tight">
              Seu negócio <br />
              <span className="text-gradient">merece crescer</span> <br />
              no digital.
            </h1>

            <p className="mt-5 text-[15px] md:text-[16px] leading-relaxed text-white/70 max-w-[520px]">
              Atraia novos clientes com <span className="text-white font-semibold">tráfego pago</span>, transforme visitantes em oportunidades com um <span className="text-white font-semibold">site profissional</span> e automatize seu atendimento com <span className="text-white font-semibold">inteligência artificial.</span>
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-3">
              <a href={WHATSAPP_LINKS.hero} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('hero', 'hero_primary')}
                className="inline-flex justify-center items-center gap-2 bg-[#00D084] hover:bg-[#00c27a] text-[#031022] font-extrabold text-[14px] tracking-wide px-8 py-4 rounded-full transition btn-glow">
                QUERO ATRAIR MAIS CLIENTES <span>→</span>
              </a>
              <button onClick={() => scrollTo('servicos')} className="inline-flex justify-center items-center gap-2 bg-white/10 hover:bg-white/15 backdrop-blur border border-white/15 text-white font-semibold text-[14px] px-8 py-4 rounded-full transition">
                Conheça nossas soluções <span className="w-6 h-6 rounded-full bg-white text-[#031022] flex items-center justify-center text-xs">↗</span>
              </button>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-6 text-[12px] text-white/60">
              <span className="flex items-center gap-2"><span className="text-[#00D084]">✔</span> Sem fidelidade abusiva</span>
              <span className="flex items-center gap-2"><span className="text-[#00D084]">✔</span> Foco em negócios locais</span>
              <span className="flex items-center gap-2"><span className="text-[#00D084]">✔</span> Atendimento humano</span>
            </div>

            {/* Social proof micro */}
            <div className="mt-6 flex items-center gap-3 glass rounded-full px-4 py-2 w-fit">
              <div className="flex -space-x-2">
                <img src="https://i.pravatar.cc/100?img=33" className="w-7 h-7 rounded-full border-2 border-[#050E1F]" alt="" />
                <img src="https://i.pravatar.cc/100?img=12" className="w-7 h-7 rounded-full border-2 border-[#050E1F]" alt="" />
                <img src="https://i.pravatar.cc/100?img=8" className="w-7 h-7 rounded-full border-2 border-[#050E1F]" alt="" />
              </div>
              <div className="text-[11px] leading-tight">
                <div className="flex text-[#FFC24C] text-[10px]">★★★★★</div>
                <div className="text-white/70">Empresas de Guarulhos confiam no nosso trabalho</div>
              </div>
            </div>
          </div>

          {/* Right Visual Composition */}
          <div className="relative lg:h-[560px] flex items-center justify-center">
            {/* Glow behind */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#00B6FF]/20 via-transparent to-[#00D084]/15 blur-3xl rounded-[40px]" />

            <div className="relative w-full max-w-[560px]">
              {/* Main Dashboard Card */}
              <div className="glass-strong rounded-[20px] p-4 md:p-5 shadow-2xl animate-float">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#00D084] flex items-center justify-center text-[#031022] font-bold text-sm">◈</div>
                    <div>
                      <div className="text-[11px] font-bold tracking-widest text-white/60">DASHBOARD</div>
                      <div className="text-[13px] font-bold">Performance Geral</div>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-[#00D084] text-[#031022] text-[10px] font-extrabold">AO VIVO</span>
                </div>

                {/* Chart area */}
                <div className="bg-[#0B1E3A] rounded-xl p-4 border border-white/5">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[11px] text-white/50 font-semibold">LEADS ESTE MÊS</span>
                    <span className="text-[11px] text-[#00D084] font-bold">▲ +32% vs mês anterior</span>
                  </div>
                  <div className="flex items-end gap-1.5 h-[70px]">
                    {[35, 50, 42, 68, 55, 80, 62, 90, 75, 95].map((h, i) => (
                      <div key={i} className="flex-1 rounded-t-lg transition-all" style={{
                        height: `${h}%`,
                        background: i >= 7 ? 'linear-gradient(180deg, #00D084 0%, #00B6FF 100%)' : i >= 4 ? 'rgba(0,182,255,0.8)' : 'rgba(255,255,255,0.15)'
                      }} />
                    ))}
                  </div>
                  <div className="flex justify-between mt-2 text-[10px] text-white/30">
                    <span>Sem 1</span><span>Sem 2</span><span>Sem 3</span><span>Sem 4</span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="bg-white/[0.06] rounded-xl p-3 border border-white/5">
                    <div className="text-[10px] text-white/50">VISITAS</div>
                    <div className="text-lg font-extrabold">8.4k</div>
                    <div className="text-[10px] text-[#00D084]">+18%</div>
                  </div>
                  <div className="bg-white/[0.06] rounded-xl p-3 border border-white/5">
                    <div className="text-[10px] text-white/50">CONVERSÕES</div>
                    <div className="text-lg font-extrabold">312</div>
                    <div className="text-[10px] text-[#00D084]">+24%</div>
                  </div>
                  <div className="bg-[#00D084] rounded-xl p-3 text-[#031022]">
                    <div className="text-[10px] font-bold opacity-70">WHATSAPP</div>
                    <div className="text-lg font-extrabold">189</div>
                    <div className="text-[10px] font-bold">novos contatos</div>
                  </div>
                </div>
              </div>

              {/* Floating Notebook Site Preview */}
              <div className="absolute -bottom-6 -left-4 md:-left-8 w-[220px] md:w-[260px] glass-strong rounded-[16px] p-3 shadow-2xl animate-float-delay hidden sm:block">
                <div className="flex items-center gap-1.5 mb-2">
                  <span className="w-3 h-3 rounded-full bg-[#FF5F56]" /><span className="w-3 h-3 rounded-full bg-[#FFBD2E]" /><span className="w-3 h-3 rounded-full bg-[#27C93F]" />
                  <span className="ml-auto text-[10px] text-white/40">seusite.com.br</span>
                </div>
                <div className="bg-white rounded-lg p-3 text-[#031022]">
                  <div className="h-2 w-16 bg-[#031022] rounded-full mb-2" />
                  <div className="h-1.5 w-full bg-gray-200 rounded-full mb-1" />
                  <div className="h-1.5 w-3/4 bg-gray-200 rounded-full mb-3" />
                  <div className="bg-[#00D084] text-white text-[10px] font-bold py-1.5 rounded-full text-center">Agendar visita</div>
                </div>
                <div className="mt-2 flex items-center gap-2 text-[10px] text-white/60">
                  <span className="w-2 h-2 bg-[#00D084] rounded-full" /> Site carregando em 1.2s
                </div>
              </div>

              {/* Floating Phone IA */}
              <div className="absolute -top-4 -right-2 md:right-0 w-[160px] glass-strong rounded-[22px] p-3 shadow-2xl animate-float hidden md:block border border-white/15">
                <div className="bg-[#0B1E3A] rounded-2xl p-3 border border-white/10">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#00D084] to-[#00B6FF] flex items-center justify-center text-[11px]">🤖</div>
                    <div>
                      <div className="text-[11px] font-bold">Assistente IA</div>
                      <div className="text-[10px] text-[#00D084]">● online agora</div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="bg-white/10 rounded-2xl rounded-bl-sm px-3 py-2 text-[11px] leading-tight">Olá! Como posso ajudar sua empresa hoje?</div>
                    <div className="bg-[#00D084] text-[#031022] rounded-2xl rounded-br-sm px-3 py-2 text-[11px] font-semibold ml-4">Quero agendar uma visita</div>
                    <div className="bg-white/10 rounded-2xl rounded-bl-sm px-3 py-2 text-[11px] leading-tight">Perfeito! Temos horário amanhã às 14h. Confirmo?</div>
                  </div>
                  <div className="mt-3 flex items-center gap-2 bg-white rounded-full px-3 py-2">
                    <span className="text-[11px] text-gray-400 flex-1">Digite...</span>
                    <span className="w-6 h-6 bg-[#00D084] rounded-full flex items-center justify-center text-[10px]">➤</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* PROBLEMA */}
      <section id="problema" ref={problemasRef} className="relative py-14 md:py-20 bg-[#070F26] border-t border-white/5">
        <div className="max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-bold tracking-widest text-[#00D084]">DIAGNÓSTICO</div>
            <h2 className="mt-4 text-[30px] md:text-[42px] font-extrabold leading-tight tracking-tight">
              Sua empresa está sendo <br />
              <span className="text-white/60">encontrada pelos clientes certos?</span>
            </h2>
            <p className="mt-4 text-[14px] md:text-[15px] text-white/60 leading-relaxed">
              Muitas empresas locais enfrentam desafios parecidos. Veja se algum desses pontos faz sentido para o seu momento — e como podemos ajudar a resolver.
            </p>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-5">
            {[
              {
                n: "01",
                title: "Depender só de indicações",
                desc: "Quando novos clientes vêm apenas por indicação, o crescimento fica imprevisível. Uma estratégia digital ajuda a atrair demanda de forma consistente.",
                icon: "◐",
                accent: "from-[#00D084]/20 to-transparent"
              },
              {
                n: "02",
                title: "Presença digital que não transmite confiança",
                desc: "Um site desatualizado ou redes sem estratégia podem afastar quem já demonstrou interesse. Profissionalismo gera contato.",
                icon: "▭",
                accent: "from-[#00B6FF]/20 to-transparent"
              },
              {
                n: "03",
                title: "Perder oportunidades por demora",
                desc: "Responder horas depois faz o cliente procurar o concorrente. Automação organiza e acelera o primeiro atendimento.",
                icon: "◷",
                accent: "from-[#A855F7]/20 to-transparent"
              },
            ].map((card) => (
              <div key={card.n} className="relative glass rounded-[20px] p-6 md:p-7 overflow-hidden group hover:bg-white/[0.08] transition">
                <div className={`absolute inset-0 bg-gradient-to-br ${card.accent} opacity-60 pointer-events-none`} />
                <div className="relative">
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-11 h-11 rounded-xl bg-white/10 border border-white/10 flex items-center justify-center text-white/80 text-lg">{card.icon}</div>
                    <span className="text-[12px] font-extrabold tracking-widest text-white/20">{card.n}</span>
                  </div>
                  <h3 className="text-[18px] font-bold leading-tight">{card.title}</h3>
                  <p className="mt-3 text-[13.5px] leading-relaxed text-white/60">{card.desc}</p>
                  <div className="mt-5 inline-flex items-center gap-2 text-[12px] font-semibold text-[#00D084]">
                    <span className="w-5 h-0.5 bg-[#00D084]/50" /> Entenda como resolvemos
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 flex justify-center">
            <div className="flex items-center gap-3 glass rounded-full px-5 py-3 text-[13px] text-white/70">
              <span className="hidden sm:inline">Se identificou com algum ponto?</span>
              <a href={WHATSAPP_LINKS.especialista} target="_blank" onClick={() => handleWpp('especialista', 'problema_cta')} className="text-[#00D084] font-bold hover:underline">Fale com um especialista →</a>
            </div>
          </div>
        </div>
      </section>

      {/* SERVIÇOS */}
      <section id="servicos" ref={servicosRef} className="relative py-14 md:py-20 bg-[#050E1F]">
        <div className="absolute inset-0 bg-gradient-to-b from-[#070F26] to-transparent pointer-events-none" />
        <div className="relative max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00D084]/10 border border-[#00D084]/20 text-[11px] font-bold tracking-widest text-[#00D084]">NOSSAS SOLUÇÕES</div>
              <h2 className="mt-4 text-[32px] md:text-[42px] font-extrabold leading-none tracking-tight">
                Tudo para sua empresa <br />
                <span className="text-gradient">atrair e converter</span>
              </h2>
            </div>
            <p className="max-w-[420px] text-[14px] leading-relaxed text-white/60">
              Três pilares que trabalham juntos: visibilidade, conversão e atendimento. Escolha o que faz mais sentido agora ou combine todos.
            </p>
          </div>

          <div className="mt-10 grid md:grid-cols-3 gap-6">
            {/* Card 1 Trafego */}
            <div className="relative rounded-[24px] overflow-hidden bg-gradient-to-b from-[#0E2040] to-[#0A1930] border border-white/10 p-6 md:p-7 flex flex-col group hover:-translate-y-1 transition duration-300">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-[#00B6FF]/15 blur-[40px] rounded-full" />
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00B6FF] to-[#0066FF] flex items-center justify-center text-xl shadow-lg">🎯</div>
                <div className="mt-4 inline-flex px-2.5 py-1 rounded-full bg-[#00B6FF]/15 border border-[#00B6FF]/20 text-[10px] font-bold tracking-widest text-[#7DD3FF]">TRÁFEGO PAGO</div>
                <h3 className="mt-3 text-[20px] font-extrabold leading-tight">Mais visibilidade <br /> para sua empresa</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-white/60 flex-1">Campanhas estratégicas no Google e nas redes sociais para alcançar potenciais clientes e gerar oportunidades comerciais.</p>

                <ul className="mt-5 space-y-2.5 text-[13px] text-white/80">
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Google Ads e Meta Ads</li>
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Segmentação local precisa</li>
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Relatórios de desempenho</li>
                </ul>

                <a href={WHATSAPP_LINKS.trafego} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('trafego', 'card_trafego')}
                  className="mt-6 w-full inline-flex justify-center items-center gap-2 bg-white text-[#031022] font-extrabold text-[13px] py-3.5 rounded-full hover:bg-gray-100 transition">
                  Quero saber mais <span>→</span>
                </a>
                <div className="mt-3 text-center text-[11px] text-white/40">Resposta em até 15 min • Sem compromisso</div>
              </div>
            </div>

            {/* Card 2 Sites */}
            <div className="relative rounded-[24px] overflow-hidden bg-gradient-to-b from-[#0F2342] to-[#0A1930] border border-white/10 p-6 md:p-7 flex flex-col group hover:-translate-y-1 transition duration-300">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-[#00D084]/15 blur-[40px] rounded-full" />
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00D084] to-[#00B6FF] flex items-center justify-center text-xl shadow-lg">🖥️</div>
                <div className="mt-4 inline-flex px-2.5 py-1 rounded-full bg-[#00D084]/15 border border-[#00D084]/20 text-[10px] font-bold tracking-widest text-[#6EE7B7]">SITES PROFISSIONAIS</div>
                <h3 className="mt-3 text-[20px] font-extrabold leading-tight">Transforme visitas <br /> em contatos</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-white/60 flex-1">Sites e landing pages profissionais, rápidos e adaptados para dispositivos móveis, com foco em apresentar seus serviços e facilitar o contato.</p>

                <ul className="mt-5 space-y-2.5 text-[13px] text-white/80">
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Design rápido e responsivo</li>
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Botão WhatsApp em destaque</li>
                  <li className="flex gap-2"><span className="text-[#00D084]">✓</span> Otimizado para SEO local</li>
                </ul>

                <a href={WHATSAPP_LINKS.sites} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('sites', 'card_sites')}
                  className="mt-6 w-full inline-flex justify-center items-center gap-2 bg-[#00D084] text-[#031022] font-extrabold text-[13px] py-3.5 rounded-full hover:bg-[#00c27a] transition btn-glow">
                  Quero saber mais <span>→</span>
                </a>
                <div className="mt-3 text-center text-[11px] text-white/40">Entrega ágil • Pronto para anunciar</div>
              </div>
            </div>

            {/* Card 3 IA */}
            <div className="relative rounded-[24px] overflow-hidden bg-gradient-to-b from-[#1A1440] to-[#0E1430] border border-white/10 p-6 md:p-7 flex flex-col group hover:-translate-y-1 transition duration-300">
              <div className="absolute -top-20 -right-20 w-60 h-60 bg-[#A855F7]/20 blur-[40px] rounded-full" />
              <div className="absolute top-4 right-4 px-2.5 py-1 rounded-full bg-[#A855F7] text-white text-[10px] font-extrabold tracking-widest">NOVO</div>
              <div className="relative">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#A855F7] to-[#00B6FF] flex items-center justify-center text-xl shadow-lg">🤖</div>
                <div className="mt-4 inline-flex px-2.5 py-1 rounded-full bg-[#A855F7]/15 border border-[#A855F7]/20 text-[10px] font-bold tracking-widest text-[#D8B4FE]">AGENTES DE IA</div>
                <h3 className="mt-3 text-[20px] font-extrabold leading-tight">Atendimento inteligente <br /> no WhatsApp</h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-white/60 flex-1">Automatize respostas frequentes, organize informações e ajude sua empresa a atender interessados com mais agilidade.</p>

                <ul className="mt-5 space-y-2.5 text-[13px] text-white/80">
                  <li className="flex gap-2"><span className="text-[#A855F7]">✓</span> Respostas 24h em segundos</li>
                  <li className="flex gap-2"><span className="text-[#A855F7]">✓</span> Qualificação automática</li>
                  <li className="flex gap-2"><span className="text-[#A855F7]">✓</span> Integração com WhatsApp</li>
                </ul>

                <a href={WHATSAPP_LINKS.ia} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('ia', 'card_ia')}
                  className="mt-6 w-full inline-flex justify-center items-center gap-2 bg-white text-[#031022] font-extrabold text-[13px] py-3.5 rounded-full hover:bg-gray-100 transition">
                  Quero saber mais <span>→</span>
                </a>
                <div className="mt-3 text-center text-[11px] text-white/40">Teste gratuito • Configuração assistida</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section id="como-funciona" className="relative py-14 md:py-20 bg-[#070F26] border-y border-white/5">
        <div className="max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <div className="inline-flex px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] font-bold tracking-widest text-white/70">COMO FUNCIONA</div>
            <h2 className="mt-4 text-[30px] md:text-[40px] font-extrabold leading-tight">Um processo simples, <br /> <span className="text-white/60">sem complicação</span></h2>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-6 relative">
            {/* line */}
            <div className="hidden md:block absolute top-[44px] left-[10%] right-[10%] h-[2px] bg-gradient-to-r from-[#00D084]/0 via-white/10 to-[#00B6FF]/0" />

            {[
              { step: "01", title: "Entendemos seu negócio", desc: "Conversamos sobre seus objetivos, público e o que já funciona hoje. Sem jargão, foco no que importa.", color: "#00D084", icon: "◍" },
              { step: "02", title: "Montamos a estratégia", desc: "Definimos os canais, mensagens e estrutura ideal para atrair os clientes certos para você.", color: "#00B6FF", icon: "⬢" },
              { step: "03", title: "Implementamos e acompanhamos", desc: "Colocamos no ar e medimos os resultados, ajustando para melhorar continuamente.", color: "#A855F7", icon: "⬣" },
            ].map((s) => (
              <div key={s.step} className="relative glass rounded-[20px] p-7 text-center hover:bg-white/[0.08] transition">
                <div className="mx-auto w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold border"
                  style={{ background: `${s.color}15`, borderColor: `${s.color}30`, color: s.color }}>
                  {s.icon}
                </div>
                <div className="mt-3 text-[11px] font-extrabold tracking-[0.2em] text-white/30">PASSO {s.step}</div>
                <h3 className="mt-2 text-[18px] font-bold">{s.title}</h3>
                <p className="mt-2 text-[13.5px] leading-relaxed text-white/60">{s.desc}</p>
                <div className="mt-5 w-8 h-8 mx-auto rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white/40">→</div>
              </div>
            ))}
          </div>

          <div className="mt-10 flex justify-center">
            <a href={WHATSAPP_LINKS.especialista} target="_blank" onClick={() => handleWpp('especialista', 'como_funciona_cta')}
              className="inline-flex items-center gap-3 glass hover:bg-white/10 text-white font-bold px-6 py-3 rounded-full transition">
              Quero começar agora <span className="w-8 h-8 rounded-full bg-[#00D084] text-[#031022] flex items-center justify-center">→</span>
            </a>
          </div>
        </div>
      </section>

      {/* DEMONSTRAÇÃO */}
      <section id="demonstracao" className="relative py-14 md:py-20 overflow-hidden">
        <div className="absolute inset-0 bg-[#050E1F]" />
        <div className="absolute -left-[200px] top-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#A855F7]/10 blur-[100px] rounded-full" />
        <div className="absolute -right-[200px] top-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#00D084]/10 blur-[100px] rounded-full" />

        <div className="relative max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8">
          <div className="rounded-[28px] bg-gradient-to-br from-[#0E1E3D] via-[#0D1B33] to-[#0A1430] border border-white/10 p-6 md:p-10 grid lg:grid-cols-[1.1fr_0.9fr] gap-8 items-center overflow-hidden">
            {/* phone mock */}
            <div className="order-2 lg:order-1 relative flex justify-center">
              <div className="relative w-[280px]">
                <div className="absolute -inset-6 bg-gradient-to-br from-[#00D084]/20 to-[#00B6FF]/20 blur-2xl rounded-[40px]" />
                <div className="relative bg-[#0B1E3A] rounded-[32px] p-3 border border-white/15 shadow-2xl">
                  <div className="bg-[#111827] rounded-[24px] overflow-hidden border border-white/10">
                    <div className="bg-[#0D1B33] px-4 py-3 flex items-center gap-3 border-b border-white/5">
                      <img src="https://i.pravatar.cc/100?img=15" className="w-8 h-8 rounded-full" alt="" />
                      <div className="flex-1">
                        <div className="text-[13px] font-bold flex items-center gap-2">Clínica Essence <span className="w-4 h-4 bg-[#00D084] rounded-full flex items-center justify-center text-[8px]">✓</span></div>
                        <div className="text-[11px] text-[#00D084]">Agente IA • online</div>
                      </div>
                      <span className="text-white/40">⋯</span>
                    </div>
                    <div className="p-4 space-y-3 bg-[#0A1020] min-h-[320px]">
                      <div className="text-center text-[10px] text-white/30 py-1">Hoje</div>
                      <div className="bg-[#1F2937] text-white/90 rounded-2xl rounded-bl-sm px-4 py-3 text-[13px] leading-snug max-w-[85%]">Olá! 👋 Bem-vinda à Clínica Essence. Como posso te ajudar hoje?</div>
                      <div className="flex gap-2 flex-wrap">
                        <span className="px-3 py-1.5 rounded-full bg-white/10 border border-white/10 text-[11px]">💆 Agendar avaliação</span>
                        <span className="px-3 py-1.5 rounded-full bg-white/10 border border-white/10 text-[11px]">💰 Valores</span>
                      </div>
                      <div className="bg-[#00D084] text-[#031022] rounded-2xl rounded-br-sm px-4 py-3 text-[13px] font-medium ml-auto max-w-[85%]">Quero agendar avaliação</div>
                      <div className="bg-[#1F2937] text-white/90 rounded-2xl rounded-bl-sm px-4 py-3 text-[13px] leading-snug max-w-[90%]">
                        Perfeito! Temos horários amanhã às <b>14h</b> ou <b>16h30</b>. Qual prefere?
                        <div className="mt-2 flex gap-2">
                          <span className="px-3 py-1 rounded-full bg-[#00D084] text-[#031022] text-[11px] font-bold">14h</span>
                          <span className="px-3 py-1 rounded-full bg-white/10 text-white text-[11px]">16h30</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-white/30">
                        <span className="w-2 h-2 bg-[#00D084] rounded-full animate-pulse" /> Agente digitando...
                      </div>
                    </div>
                    <div className="p-3 bg-[#0D1B33] flex items-center gap-2 border-t border-white/5">
                      <div className="flex-1 bg-white rounded-full px-4 py-2.5 text-[12px] text-gray-400">Digite sua mensagem...</div>
                      <div className="w-9 h-9 bg-[#00D084] rounded-full flex items-center justify-center text-[#031022]">➤</div>
                    </div>
                  </div>
                </div>
                {/* badges */}
                <div className="absolute -right-6 top-12 glass rounded-full px-3 py-2 text-[11px] font-bold flex items-center gap-2">
                  <span className="w-2 h-2 bg-[#00D084] rounded-full" /> Resposta em 3s
                </div>
                <div className="absolute -left-4 bottom-12 glass rounded-full px-3 py-2 text-[11px] font-bold">
                  ⚡ Disponível 24h
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#A855F7]/15 border border-[#A855F7]/20 text-[11px] font-bold tracking-widest text-[#D8B4FE]">DEMONSTRAÇÃO AO VIVO</div>
              <h2 className="mt-4 text-[30px] md:text-[38px] font-extrabold leading-tight">
                Veja a inteligência <br />
                artificial <span className="text-gradient">funcionando na prática.</span>
              </h2>
              <p className="mt-4 text-[14px] leading-relaxed text-white/60">
                Experimente uma demonstração de atendimento automatizado e descubra como essa tecnologia pode ajudar sua empresa a não perder nenhum contato — mesmo fora do horário.
              </p>

              <ul className="mt-6 space-y-3 text-[13px] text-white/80">
                <li className="flex items-center gap-3"><span className="w-7 h-7 rounded-full bg-[#00D084]/15 border border-[#00D084]/20 flex items-center justify-center text-[#00D084] text-xs">✓</span> Atende em segundos, 24 horas por dia</li>
                <li className="flex items-center gap-3"><span className="w-7 h-7 rounded-full bg-[#00D084]/15 border border-[#00D084]/20 flex items-center justify-center text-[#00D084] text-xs">✓</span> Qualifica e agenda sem intervenção manual</li>
                <li className="flex items-center gap-3"><span className="w-7 h-7 rounded-full bg-[#00D084]/15 border border-[#00D084]/20 flex items-center justify-center text-[#00D084] text-xs">✓</span> Integrado ao seu WhatsApp Business</li>
              </ul>

              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <a href={WHATSAPP_LINKS.demonstracao} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('demonstracao', 'demo_primary')}
                  className="inline-flex justify-center items-center gap-2 bg-[#00D084] hover:bg-[#00c27a] text-[#031022] font-extrabold px-7 py-4 rounded-full btn-glow transition">
                  TESTAR A IA NO WHATSAPP <span>↗</span>
                </a>
                <button onClick={() => showToast('Demonstração disponível apenas via WhatsApp')} className="inline-flex justify-center items-center gap-2 bg-white/10 hover:bg-white/15 border border-white/15 text-white font-semibold px-6 py-4 rounded-full transition">
                  Ver exemplo de conversa
                </button>
              </div>
              <div className="mt-4 text-[11px] text-white/40">Demonstração gratuita • Sem instalação técnica • Teste em 1 minuto</div>
            </div>
          </div>
        </div>
      </section>

      {/* CHAMADA FINAL */}
      <section className="relative py-14 md:py-24 overflow-hidden">
        <div className="absolute inset-0 bg-[#050E1F]" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#00D084]/10 via-transparent to-transparent" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] bg-[#00B6FF]/10 blur-[100px] rounded-full pointer-events-none" />

        <div className="relative max-w-[900px] mx-auto px-4 md:px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-[11px] font-bold tracking-widest text-white/60">PRÓXIMO PASSO</div>
          <h2 className="mt-5 text-[34px] md:text-[48px] font-extrabold leading-[0.95] tracking-tight">
            Vamos construir o <br />
            <span className="text-gradient">próximo passo</span> <br />
            do seu negócio?
          </h2>
          <p className="mt-5 text-[15px] leading-relaxed text-white/60 max-w-[600px] mx-auto">
            Converse conosco, explique o que sua empresa precisa e receba uma sugestão de estratégia digital — sem compromisso e com linguagem simples.
          </p>

          <div className="mt-8 flex justify-center">
            <a href={WHATSAPP_LINKS.especialista} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('especialista', 'final_cta')}
              className="inline-flex items-center gap-3 bg-[#00D084] hover:bg-[#00c27a] text-[#031022] font-extrabold text-[16px] px-10 py-5 rounded-full btn-glow transition">
              FALAR COM UM ESPECIALISTA <span className="w-8 h-8 rounded-full bg-[#031022] text-[#00D084] flex items-center justify-center">→</span>
            </a>
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-6 text-[12px] text-white/50">
            <span className="flex items-center gap-2"><span className="w-2 h-2 bg-[#00D084] rounded-full" /> Resposta rápida no WhatsApp</span>
            <span className="flex items-center gap-2"><span className="w-2 h-2 bg-[#00D084] rounded-full" /> Atendimento humano</span>
            <span className="flex items-center gap-2"><span className="w-2 h-2 bg-[#00D084] rounded-full" /> Sem spam</span>
          </div>

          <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4 text-left">
            {[
              { title: "Clínicas e estética", desc: "Mais agendamentos e lembretes automáticos." },
              { title: "Serviços locais", desc: "Destaque no Google e orçamentos no WhatsApp." },
              { title: "Comércio e lojas", desc: "Vitrine digital que gera visitas e vendas." },
            ].map(c => (
              <div key={c.title} className="glass rounded-2xl p-5">
                <div className="text-[13px] font-bold">{c.title}</div>
                <div className="text-[12px] text-white/60 mt-1">{c.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* RODAPÉ */}
      <footer className="bg-[#030A1A] border-t border-white/5">
        <div className="max-w-[1220px] mx-auto px-4 md:px-6 lg:px-8 py-10">
          <div className="grid md:grid-cols-[1.5fr_1fr_1fr] gap-10">
            <div>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00D084] to-[#00B6FF] flex items-center justify-center font-extrabold text-[#031022]">◈</div>
                <div className="font-extrabold text-[16px]" style={{ fontFamily: 'Sora, sans-serif' }}>{agenciaNome}</div>
                <span className="px-2 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-bold tracking-widest text-white/60">PREMIUM</span>
              </div>
              <p className="mt-4 text-[13px] leading-relaxed text-white/50 max-w-[380px]">
                Ajudamos empresas de Guarulhos e região a atrair mais clientes com tráfego pago, sites profissionais e automação inteligente no WhatsApp.
              </p>
              <div className="mt-5 inline-flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 border border-white/10 text-[12px] text-white/70">
                📍 Atendimento em Guarulhos e região • São Paulo, Brasil
              </div>
            </div>

            <div>
              <div className="text-[11px] font-extrabold tracking-[0.18em] text-white/40">CONTATO</div>
              <div className="mt-4 space-y-3 text-[13px]">
                <a href={WHATSAPP_LINKS.hero} target="_blank" onClick={() => handleWpp('hero', 'footer_whatsapp')} className="flex items-center gap-2 text-white hover:text-[#00D084] transition"><span className="w-7 h-7 rounded-full bg-[#00D084] flex items-center justify-center text-[12px]">✆</span> (11) 95385-1744</a>
                <a href="mailto:nicotech.contato@gmail.com" onClick={() => trackEvent('email_click', { email: 'nicotech.contato@gmail.com' })} className="flex items-center gap-2 text-white/80 hover:text-white transition"><span className="w-7 h-7 rounded-full bg-white/10 border border-white/10 flex items-center justify-center text-[11px]">✉︎</span> nicotech.contato@gmail.com</a>
                <a href="https://www.instagram.com/nic_otech/" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent('instagram_click', { handle: 'nic_otech' })} className="flex items-center gap-2 text-white/80 hover:text-white transition"><span className="w-7 h-7 rounded-full bg-gradient-to-br from-[#833AB4] via-[#FD1D1D] to-[#FCAF45] flex items-center justify-center text-[12px]">◎</span> @nic_otech</a>
                <div className="text-white/40 text-[12px]">Seg–Sex • 9h às 18h • Guarulhos e região</div>
                <div className="flex gap-2 pt-2">
                  <a href="https://www.instagram.com/nic_otech/" target="_blank" rel="noopener noreferrer" onClick={() => trackEvent('instagram_click', { button: 'footer_cta' })} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white text-[#031022] text-[12px] font-extrabold hover:bg-gray-100 transition">Ver Instagram →</a>
                  <a href="mailto:nicotech.contato@gmail.com" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 border border-white/15 text-white text-[12px] font-bold hover:bg-white/15 transition">Enviar e-mail</a>
                </div>
              </div>
            </div>

            <div>
              <div className="text-[11px] font-extrabold tracking-[0.18em] text-white/40">NAVEGAÇÃO</div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-[13px] text-white/60">
                <button onClick={() => scrollTo('problema')} className="text-left hover:text-white">Como ajudamos</button>
                <button onClick={() => scrollTo('servicos')} className="text-left hover:text-white">Serviços</button>
                <button onClick={() => scrollTo('como-funciona')} className="text-left hover:text-white">Processo</button>
                <button onClick={() => scrollTo('demonstracao')} className="text-left hover:text-white">Demonstração</button>
                <a href={WHATSAPP_LINKS.hero} target="_blank" className="hover:text-white">WhatsApp</a>
                <button onClick={() => showToast('Política de privacidade em breve')} className="text-left hover:text-white">Privacidade</button>
              </div>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-white/5 flex flex-col md:flex-row justify-between gap-4 text-[11px] text-white/30">
            <div>© {new Date().getFullYear()} {agenciaNome} — Todos os direitos reservados. Atendimento em Guarulhos e região.</div>
            <div className="flex gap-4">
              <button onClick={() => showToast('Política de privacidade: Seus dados são usados apenas para contato. Não compartilhamos com terceiros.')} className="hover:text-white/60 underline">Política de Privacidade</button>
              <span>•</span>
              <span>Aviso: Não garantimos resultados; trabalhamos com estratégia e acompanhamento.</span>
            </div>
          </div>

          <div className="mt-4 p-3 rounded-xl bg-white/[0.03] border border-white/5 text-[11px] leading-relaxed text-white/35">
            <b className="text-white/50">Privacidade:</b> Ao falar conosco pelo WhatsApp, você concorda em compartilhar seu nome e mensagem para atendimento. Não enviamos spam e você pode solicitar a exclusão dos seus dados a qualquer momento. Esta página não coleta dados automaticamente. Eventos de clique são registrados anonimamente apenas para melhoria da experiência.
          </div>
        </div>
      </footer>

      {/* WhatsApp Floating */}
      <a href={WHATSAPP_LINKS.hero} target="_blank" rel="noopener noreferrer" onClick={() => handleWpp('hero', 'floating_button')}
        className="fixed bottom-5 right-5 z-50 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-[0_8px_24px_rgba(0,0,0,0.4)] hover:scale-105 transition group">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M19.05 4.91A9.82 9.82 0 0 0 12.01 2C6.48 2 2.01 6.48 2.01 12.01c0 1.76.46 3.49 1.33 5.01L2 22l5.1-1.34A9.82 9.82 0 0 0 12.01 22c5.53 0 10.01-4.48 10.01-10.01 0-2.67-1.04-5.19-2.97-7.08Zm-7.04 13.56c-1.47 0-2.91-.4-4.16-1.15l-.3-.18-3.02.79.8-2.94-.2-.3A8.02 8.02 0 0 1 12.01 4c4.41 0 8.01 3.59 8.01 8.01 0 4.41-3.6 8.01-8.01 8.46Zm4.4-6.01c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.93-1.19-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.02-.37.1-.49.1-.1.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.39-.41-.54-.42h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.31.98 2.47.12.16 1.69 2.58 4.1 3.62.57.25 1.02.4 1.37.51.58.18 1.1.16 1.52.1.46-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28Z" /></svg>
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-white animate-pulse" />
      </a>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#0B1E3A] border border-white/15 text-white px-5 py-3 rounded-full shadow-2xl text-sm z-50">
          {toast}
        </div>
      )}
    </div>
  )
}
